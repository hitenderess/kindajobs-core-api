export class SignupDto {
    
}