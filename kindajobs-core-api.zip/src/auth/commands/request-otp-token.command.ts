export class RequestOtpTokenCommand {
    constructor(public readonly mobileNumber: string) {}
}