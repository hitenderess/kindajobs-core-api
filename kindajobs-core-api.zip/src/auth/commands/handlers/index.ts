import { RequestOtpTokenHandler } from './request-otp-token.handler';

export const CommandHandlers = [
    //RequestOtpTokenHandler()
]