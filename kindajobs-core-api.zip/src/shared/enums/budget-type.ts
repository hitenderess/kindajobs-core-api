export enum BudgetType {
    Hourly =  'HOURLY',
    FixedBudget = 'FIXED_BUDGET', 
}