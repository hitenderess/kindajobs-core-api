import { Controller } from '@nestjs/common';

@Controller('job-application')
export class JobApplicationController {}
