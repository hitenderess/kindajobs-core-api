import { Auth } from "src/auth/entities/auth.entity";
import { Column, Entity, ManyToOne } from "typeorm";
import { AbstractEntity } from "../shared/entities/abstract.entity";

@Entity('job-application')
export class Job extends AbstractEntity {

    
    @Column({
        default: true
    })
    is_active: boolean;

    @Column()
    title: string;

    @Column()
    description: string;

    @Column()
    job_price:number;

    @Column()
    commission:number;

    @Column()
    total_amount:number;

    @Column()
    job_status:string;

    @ManyToOne(() => Auth, auth => auth.jobs)
    user: Auth;
}
